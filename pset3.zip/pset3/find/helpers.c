/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>
#include <math.h>
#include "helpers.h"
#include <stdio.h>

/**
 * Returns true if value is in array of n values, else false.
 */
bool search(int value, int values[], int n)
{
    // TODO: implement a searching algorithm
    //binary search, divide and conquer sorted array now
    
    int right = n;
    int middle = right/2; //int should auto round
    int left = 0;
    
    
    while (right >= left) { //sub array is bigger than 0
        
        if (value == values[middle]) {
            return true;
        }
        else if (values[middle] < value) {
            left = middle +1;
            middle = left + ((right - left) / 2);
            
        }
        else { // value < middle
            right = middle -1;
            middle = left + ((right - left) / 2);
        }
        
    } 
    
    return false;
    
}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    // TODO: implement an O(n^2) sorting algorithm
    int times = 1;
    int temp;
    
    while (times > 0) {
        times = 0;
        
        for (int i = 0; i < n - 1; i ++) {

            if (values[i] > values[i+1]) {
                
                temp = values[i];
                values[i] = values[i+1];
                values[i+1] = temp;
                times ++;
            }
         
        }
        n --;
    }
    
    return;
}